############################
### Some More Important  ###
### MDPtoolbox Functions ###
############################

# Load MDPtoolbox package
library("MDPtoolbox")

# -----------------------------------
# BELLMAN OPERATOR
# mdp_bellman_operator() 

# Description: Applies the Bellman
# operator to a value function Vprev
# and returns a new value function
# and a Vprev-improving policy. 
# The mdp_bellman_operator() function
# applies the Bellman operator: 
# PR + discount*P*Vprev to the value
# function Vprev. The function returns
# a new value function and a 
# Vprev-improving policy.

# EXAMPLES

# With a non-sparse matrix
P <- array(0, c(2,2,2))
P[,,1] <- matrix(c(0.5, 0.5, 0.8, 0.2), 
                 2, 2, 
                 byrow=TRUE)
P[,,2] <- matrix(c(0, 1, 0.1, 0.9), 
                 2, 2, 
                 byrow=TRUE)
P
R <- matrix(c(5, 10, -1, 2), 
            2, 2, 
            byrow=TRUE)
R
# check validity
mdp_check(P, R)
# run bellman function
mdp_bellman_operator(P, R, 
                     discount = 0.9, 
                     Vprev = c(0,0))

# With a sparse matrix
P <- list()
P[[1]] <- Matrix(c(0.5, 0.5, 0.8, 0.2), 
                 2, 2, 
                 byrow=TRUE, 
                 sparse=TRUE)
P[[2]] <- Matrix(c(0, 1, 0.1, 0.9), 
                 2, 2, 
                 byrow=TRUE, 
                 sparse=TRUE)
P
mdp_bellman_operator(P, R, 0.9, c(0,0))

# -----------------------------------
# ITERATIVE EVALUATION POLICY
# mdp_eval_policy_iterative()

# Description: Iteratively evaluates 
# the value function associated with
# a policy by applying the Bellman operator.

# EXAMPLES
# With a non-sparse matrix
P <- array(0, c(2,2,2))
P[,,1] <- matrix(c(0.5, 0.5, 0.8, 0.2), 
                 2, 2, byrow=TRUE)
P[,,2] <- matrix(c(0, 1, 0.1, 0.9), 
                 2, 2, byrow=TRUE)
P
R <- matrix(c(5, 10, -1, 2), 
            2, 2, byrow=TRUE)
R
policy <- c(2,1)
mdp_eval_policy_iterative(P, R, 0.8, policy)

# With a sparse matrix
P <- list()
P[[1]] <- Matrix(c(0.5, 0.5, 0.8, 0.2), 
                 2, 2, byrow=TRUE, sparse=TRUE)
P[[2]] <- Matrix(c(0, 1, 0.1, 0.9), 
                 2, 2, byrow=TRUE, sparse=TRUE)
mdp_eval_policy_iterative(P, R, 0.8, policy)

# -----------------------------------
# COMPUTE TRANSITION AND REWARD MATRIX FROM POLICY
# mdp_computePpolicyPRpolicy

# Description: Computes the transition matrix
# and the reward matrix for a fixed policy.

# EXAMPLES
# With a non-sparse matrix
P <- array(0, c(2,2,2))
P[,,1] <- matrix(c(0.6116, 0.3884, 0, 1.0000), 
                 2, 2, byrow=TRUE)
P[,,2] <- matrix(c(0.6674, 0.3326, 0, 1.0000), 
                 2, 2, byrow=TRUE)
R <- array(0, c(2,2,2))
R[,,1] <- matrix(c(-0.2433, 0.7073, 0, 0.1871), 
                 2, 2, byrow=TRUE)
R[,,2] <- matrix(c(-0.0069, 0.6433, 0, 0.2898), 
                 2, 2, byrow=TRUE)
policy <- c(2,2)
mdp_computePpolicyPRpolicy(P, R, policy)

# With a sparse matrix (P)
P <- list()
P[[1]] <- Matrix(c(0.6116, 0.3884, 0, 1.0000), 
                 2, 2, byrow=TRUE, sparse=TRUE)
P[[2]] <- Matrix(c(0.6674, 0.3326, 0, 1.0000), 
                 2, 2, byrow=TRUE, sparse=TRUE)
mdp_computePpolicyPRpolicy(P, R, policy)

# -----------------------------------
# EVALUATES POLICY USING REINFORCEMENT LEARNING ALGORITHM
# mdp_eval_policy_TD_0()

# Description: Evaluates the value function
# associated to a policy using the TD(0) 
# algorithm (Reinforcement Learning).

# EXAMPLES
# With a non-sparse matrix
P <- array(0, c(2,2,2))
P[,,1] <- matrix(c(0.5, 0.5, 0.8, 0.2), 
                 2, 2, byrow=TRUE)
P[,,2] <- matrix(c(0, 1, 0.1, 0.9), 
                 2, 2, byrow=TRUE)
P
R <- matrix(c(5, 10, -1, 2), 2, 2, 
            byrow=TRUE)
R
mdp_eval_policy_TD_0(P, R, 
                     discount = 0.9, 
                     policy = c(1,2))

# With a sparse matrix
P <- list()
P[[1]] <- Matrix(c(0.5, 0.5, 0.8, 0.2), 
                 2, 2, byrow=TRUE, 
                 sparse=TRUE)
P[[2]] <- Matrix(c(0, 1, 0.1, 0.9), 
                 2, 2, byrow=TRUE, 
                 sparse=TRUE)
P
mdp_eval_policy_TD_0(P, R, 0.9, c(1,2))

# -----------------------------------
# ITERATIVE POLICY ALGORITHM FOR DISCOUNTED MDP
# mdp_policy_iteration()

# Description: mdp_policy_iteration applies
# the policy iteration algorithm to solve 
# discounted MDP. The algorithm serves to
# improve the policy iteratively, using the
# evaluation of the current policy. Iterating
# stops when two successive policies are 
# identical or when a specified number 
# (max_iter) of iterations have been performed.

# EXAMPLES
# With a non-sparse matrix
P <- array(0, c(2,2,2))
P[,,1] <- matrix(c(0.5, 0.5, 0.8, 0.2), 2, 2, byrow=TRUE)
P[,,2] <- matrix(c(0, 1, 0.1, 0.9), 2, 2, byrow=TRUE)
R <- matrix(c(5, 10, -1, 2), 2, 2, byrow=TRUE)
mdp_policy_iteration(P, R, 0.9)

# With a sparse matrix
P <- list()
P[[1]] <- Matrix(c(0.5, 0.5, 0.8, 0.2), 2, 2, byrow=TRUE, sparse=TRUE)
P[[2]] <- Matrix(c(0, 1, 0.1, 0.9), 2, 2, byrow=TRUE, sparse=TRUE)
mdp_policy_iteration(P, R, 0.9)

# -----------------------------------
# DISCOUNTED MDP WITH Q-LEARNING
# mdp_Q_learning()

# Description: Solves discounted MDP with the
# Q-learning algorithm (Reinforcement learning).
# mdp_Q_learning() computes the Q matrix, 
# the mean discrepancy and gives the optimal
# value function and the optimal policy when
# allocated enough iterations. 
# It uses an iterative method.

# EXAMPLES
# With a non-sparse matrix
P <- array(0, c(2,2,2))
P[,,1] <- matrix(c(0.5, 0.5, 0.8, 0.2), 
                 2, 2, byrow=TRUE)
P[,,2] <- matrix(c(0, 1, 0.1, 0.9), 
                 2, 2, byrow=TRUE)
R <- matrix(c(5, 10, -1, 2), 2, 2, 
            byrow=TRUE)
mdp_Q_learning(P, R, 0.9)

# With a sparse matrix
P <- list()
P[[1]] <- Matrix(c(0.5, 0.5, 0.8, 0.2), 
                 2, 2, byrow=TRUE, 
                 sparse=TRUE)
P[[2]] <- Matrix(c(0, 1, 0.1, 0.9), 
                 2, 2, byrow=TRUE, 
                 sparse=TRUE)
mdp_Q_learning(P, R, 0.9)
