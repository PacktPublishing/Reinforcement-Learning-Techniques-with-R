######################################
###   3 x 4 Grid World Exercise    ###
######################################

# We will use the Reinforcement Learning
# package under development. The package
# performs model-free reinforcement
# learning in a highly customizable 
# framework.

# Load the package
library(ReinforcementLearning)

# Template of environment function:
# environment <- function(state, action) {
#  . . . 
# return(list("NextState" = newState,
#             "Reward" = reward))
# }

# Can manually create your own environment
# function or use "canned" environments
# from ReinforcementLearning package.

# Load exemplary environment (gridworld)
?gridworldEnvironment

# We are going to sample experience from
# an agent that navigates from a random
# starting position to a goal position in
# a 2 x 2 version of Grid World.
env <- gridworldEnvironment
print(env)
## function(state, action) {
##   next_state <- state
##   if(state == state("s1") && action == "down") next_state <- state("s2")
##   if(state == state("s2") && action == "up") next_state <- state("s1")
##   if(state == state("s2") && action == "right") next_state <- state("s3")
##   if(state == state("s3") && action == "left") next_state <- state("s2")
##   if(state == state("s3") && action == "up") next_state <- state("s4")
## 
##   if(next_state == state("s4") && state != state("s4")) {
##     reward <- 10
##   } else {
##     reward <- -1
##   }
## 
##   out <- list("NextState" = next_state, "Reward" = reward)
##   return(out)
## }
##

# Define state and action sets
states <- c("s1", "s2", "s3", "s4")
states
actions <- c("up", "down", "left", "right")
actions

# Sample N = 1000 random sequences from the environment

# Data format must be (s,a,r,s_new) tuples
# as rows in a dataframe structure.

?sampleExperience
data <- sampleExperience(N = 1000, 
                         env = env, 
                         states = states, 
                         actions = actions)
head(data)
##   State Action Reward NextState
## 1    s1  right     -1        s1
## 2    s2   left     -1        s2
## 3    s2  right     -1        s3
## 4    s3   left     -1        s2
## 5    s3   left     -1        s2
## 6    s3  right     -1        s3

data

## Performing Reinforcement Learning

# Define reinforcement learning parameters
control <- list(alpha = 0.1, # low learning rate
                gamma = 0.5, # middle discount factor
                # epsilon only relevant when sampling
                # new experience based on existing policy
                epsilon = 0.1) # low exploration factor
control

# Perform reinforcement learning
?ReinforcementLearning
model <- ReinforcementLearning(data, 
                               s = "State", 
                               a = "Action", 
                               r = "Reward", 
                               s_new = "NextState", 
                               control = control)

# Print result
print(model)
## State-Action function Q
##         right         up       down       left
## s1 -0.6633782 -0.6687457  0.7512191 -0.6572813
## s2  3.5806843 -0.6893860  0.7760491  0.7394739
## s3  3.5702779  9.1459425  3.5765323  0.6844573
## s4 -1.8005634 -1.8567931 -1.8244368 -1.8377018
## 
## Policy
##      s1      s2      s3      s4 
##  "down" "right"    "up" "right" 
## 
## Reward (last iteration)
## [1] -263

# Print policy
policy(model)

