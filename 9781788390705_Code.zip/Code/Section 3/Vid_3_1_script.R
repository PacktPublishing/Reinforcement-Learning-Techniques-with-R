######################################
#####         MDPtoolbox         #####
######################################

# Load R library MDPtoolbox
library(MDPtoolbox)

# MDP Policy Iteration

# Design an MDP that finds the optimal 
# policy to that 2 x 2 grid problem.

# Create individual matrices with 
# pre-specified (random) transition
# probabilities for each action

# These transition matrices reflect
# the following randomness of action
# taken vis a vis action selected. When
# agent selects an action, there is
# a 70% probability that that action
# selected will occur. There is a 20%
# probability the agent will stay in
# the same state (no action taken).
# And there is a 10% probability that
# the agent will move in a lateral
# direction to the action selected.

# How to read the Up action probability matrix:
up <- matrix(c(   1,   0,   0,   0,
                0.7, 0.2, 0.1,   0,
                  0, 0.1, 0.2, 0.7,
                  0,   0,   0,   1), 
             nrow=4, ncol=4, byrow=TRUE)

# Agent is in:   S1   S2   S3   S4
# up <- matrix(c( 1,   0,   0,   0,
# Goes to:      0.7, 0.2, 0.1,   0,
# Goes to:        0, 0.1, 0.2, 0.7,
# Goes to:        0,   0,   0,   1),
#              nrow=4, ncol=4, byrow=TRUE)

# If agent is in State S1 and
# tries to go Up, there is a
# 100% probability s/he will 
# remain in State S1.
up <- matrix(c( 1, 0, 0, 0,
# If agent is in State S2 and tries
# to go Up, there is a 70% prob that
# s/he will go Up to S1, a 20% prob
# will remain in S2, and a 10% prob
# agent will go right to S3.
                0.7, 0.2, 0.1, 0,
# If agent is in State S3 and tries
# to go Up, there is a 70% prob that
# s/he will go Up to S4, a 20% prob
# will remain in S3, and a 10% prob
# s/he will move left to S2.
                0, 0.1, 0.2, 0.7,
# Finally, if agent is in State S4
# and tries to go Up, there is a
# 100% prob agent will remain in S4.
                0, 0, 0, 1),
             nrow=4, ncol=4, byrow=TRUE)
up

# How to read the Left action probability matrix:
left <- matrix(c(0.9, 0.1, 0, 0,
                 0.1, 0.9, 0, 0,
                 0, 0.7, 0.2, 0.1,
                 0, 0, 0.1, 0.9),
               nrow=4, ncol=4, byrow=TRUE)

# If agent is in State S1 and
# tries to go Left, there is a
# 90% probability s/he will 
# remain in State S1 and a 10% prob
# agent will go down to S2.
left <- matrix(c(0.9, 0.1, 0, 0,
# If agent is in State S2 and
# tries to go Left, there is a
# 90% probability agent will 
# remain in State S2 (70% prob
# hits boundary plus 20% stays
# in place) and a 10% prob agent
# moves laterally to S1.
                 0.1, 0.9, 0, 0,
# If agent is in State S3 and
# tries to go Left, there is a
# 70% probability s/he will move
# move left to S2, a 20% prob
# agent will remain in S3, and
# a 10% prob agent will go up
# laterally to S4.
                 0, 0.7, 0.2, 0.1,
# If agent is in State S4 and
# tries to go Left, there is a
# 90% probability agent will
# remain in S4 (70% prob hits wall
# plus 20% remains in place) and
# a 10% prob agent moves down
# laterally to S3.
                 0, 0, 0.1, 0.9),
               nrow=4, ncol=4, byrow=TRUE)
left

# How to read the Down action probability matrix:
down <- matrix(c(0.3, 0.7, 0, 0,
                 0, 0.9, 0.1, 0,
                 0, 0.1, 0.9, 0,
                 0, 0, 0.7, 0.3),
               nrow=4, ncol=4, byrow=TRUE)

# If agent is in State S1 and tries
# to do down, there is a 70% prob
# agent will move to S2 and a 30%
# probability agent will stay in S1
# (20% stay in place plus 10% agent
# move move left but hits boundary).
down <- matrix(c(0.3, 0.7, 0, 0,
# If agent is in State S2 and tries
# to go down, there is a 90% prob
# agent will stay in S2 (70% stay
# = 20 moves left but hits boundary)
                 0, 0.9, 0.1, 0,
                 0, 0.1, 0.9, 0,
                 0, 0, 0.7, 0.3),
               nrow=4, ncol=4, byrow=TRUE)
down

# How to read the Right action probability matrix:
right <- matrix(c(0.9, 0.1, 0, 0,
                  0.1, 0.2, 0.7, 0,
                  0, 0, 0.9, 0.1,
                  0, 0, 0.1, 0.9),
                nrow=4, ncol=4, byrow=TRUE)

# If agent is in State S1 and
# tries to go Right, there is a
# 90% probability agent will 
# remain in State S1 (70% hits
# red line and 20% stays in S1) and
# a 10% probability moves laterally
# to S2.
right <- matrix(c(0.9, 0.1, 0, 0,
# If agent is in State S2 and
# tries to go Right, there is a
# 70% probability agent will 
# move in State S3, a 20% prob
# agent will remain in S2, and a
# a 10% probability moves laterally
# to S1.
                  0.1, 0.2, 0.7, 0,
# If agent is in State S3 and
# tries to go Right, there is a
# 90% probability agent will 
# stay in S3 (70% hits wall plus
# 20% stays in place in S3) and
# a 10% prob moves laterally up
# to S4.
                  0, 0, 0.9, 0.1,
# If agent is in State S4 and
# tries to go Right, there is a
# 90% probability agent will 
# stay in S4 (70% hits wall plus
# 20% stays in place in S4) and
# a 10% prob moves laterally down
# t0 S3.
                  0, 0, 0.1, 0.9),
                nrow=4, ncol=4, byrow=TRUE)
right

# all of them
up
left 
down
right

# Aggregate previous matrices to create 
# transition probabilities into list T
T <- list(up=up, left=left,
          down=down, right=right)
T

# Create matrix with rewards:
R <- matrix(c(-1, -1, -1, -1,
              -1, -1, -1, -1,
              -1, -1, -1, -1,
              10, 10, 10, 10),
            nrow=4, ncol=4, byrow=TRUE)

# If you enter S1 from anywhere
# you get reward of -1.
R <- matrix(c(-1, -1, -1, -1,
# If you enter S2 from anywhere
# you get reward of -1.
              -1, -1, -1, -1,
# If you enter S3 from anywhere
# you get reward of -1.
              -1, -1, -1, -1,
# If you enter S4 from anywhere
# you get reward of -10.
              10, 10, 10, 10),
            nrow=4, ncol=4, byrow=TRUE)
R

# Check if this provides a well-defined MDP
# To look at help screen:
?mdp_check
mdp_check(T, R) # empty string => ok
## [1] ""

# Run policy iteration with discount factor g = 0.9
# To look at help screen:
?mdp_policy_iteration
m <- mdp_policy_iteration(P=T, 
                          R=R, 
                          discount=0.9)

# Display optimal policy p
m$policy
## [1] 3 4 1 1

names(T)[m$policy]
## [1] "down" "right" "up" "up"

# Display value function Vp
m$V
## [1] 58.25663 69.09102 83.19292 100.00000



