################################
###  Build 3 x 4 Grid World  ###  
###    Exercise Solution     ###
################################

# Load the package
library(ReinforcementLearning)


# You manually create your own environment
# to mimic 3 x 4 Grid World Example with
# rewards of 0 in all states except
# Forfeiture State (reward = -1) and
# Goal State (reward = 1)

# We are going to sample experience from
# an agent that navigates from a random
# starting position to state 4.3 (Goal)
# in the 3 x 4 version of Grid World.

GWenv <- function(state, action) {
  next_state <- state
  ## define possible states
  if(state == state("1.1") && action == "up") next_state <- state("1.2")
  if(state == state("1.1") && action == "right") next_state <- state("2.1")
  if(state == state("2.1") && action == "right") next_state <- state("3.1")
  if(state == state("2.1") && action == "left") next_state <- state("1.1")
  if(state == state("3.1") && action == "right") next_state <- state("4.1")
  if(state == state("3.1") && action == "left") next_state <- state("2.1")
  if(state == state("3.1") && action == "up") next_state <- state("3.2")
  if(state == state("4.1") && action == "left") next_state <- state("3.1")
  if(state == state("4.1") && action == "up") next_state <- state("4.2")
  if(state == state("1.2") && action == "up") next_state <- state("1.3")
  if(state == state("1.2") && action == "down") next_state <- state("1.1")
  if(state == state("3.2") && action == "right") next_state <- state("4.2")
  if(state == state("3.2") && action == "up") next_state <- state("3.3")
  if(state == state("3.2") && action == "down") next_state <- state("3.1")
  if(state == state("1.3") && action == "right") next_state <- state("2.3")
  if(state == state("1.3") && action == "down") next_state <- state("1.2")
  if(state == state("2.3") && action == "left") next_state <- state("1.3")
  if(state == state("2.3") && action == "right") next_state <- state("3.3")
  if(state == state("3.3") && action == "left") next_state <- state("2.3")
  if(state == state("3.3") && action == "right") next_state <- state("4.3")
  if(state == state("3.3") && action == "down") next_state <- state("3.2")
  
  ## define rewards in each state
  ## make them all 0
  reward <- 0
  ## Goal state 4.3 has reward of 1
  if (next_state == state("4.3") && (state == state("3.3"))) reward <- 1
  ## Forfeiture state 4.2 has reward of -1
  if (next_state == state("4.2") && (state == state("3.2"))) reward <- -1
  if (next_state == state("4.2") && (state == state("4.1"))) reward <- -1
  
  ## 
  out <- list("NextState" = next_state, "Reward" = reward)
  return(out)
}

# Define state and action sets
states <- c("1.1", "2.1", "3.1", "4.1",
            "1.2",        "3.2", "4.2",
            "1.3", "2.3", "3.3", "4.3")
states
actions <- c("up", "down", "left", "right")
actions

# Sample N = 1000 random sequences from the environment

# Data format must be (s,a,r,s_new) tuples
# as rows in a dataframe structure.

# Set seed for replicability
set.seed(1234)
# ?sampleExperience
data <- sampleExperience(N = 1000, 
                         env = GWenv, 
                         states = states, 
                         actions = actions)

# Show first 250 records of data
data

## Performing Reinforcement Learning

# Define reinforcement learning parameters
control <- list(alpha = 0.1, # low learning rate
                gamma = 0.5, # middle discount factor
                # epsilon only relevant when sampling
                # new experience based on existing policy
                epsilon = 0.1) # low exploration factor
control

# Perform reinforcement learning
# ?ReinforcementLearning
model <- ReinforcementLearning(data, 
                               s = "State", 
                               a = "Action", 
                               r = "Reward", 
                               s_new = "NextState", 
                               control = control)

# Print result
str(model)
print(model)
