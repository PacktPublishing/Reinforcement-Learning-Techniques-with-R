######################################
### Reinforcement Learning Package ###
######################################

# Updating an existing policy (Video 2.2)

# We had already run an intial data set
# and found a policy

# Load ReinforcementLearning package
# into your R session
library(ReinforcementLearning)

# Define reinforcement learning parameters
# Note we did this already
control <- list(alpha = 0.1, # low learning rate
                gamma = 0.5, # middle discount factor
                # epsilon only relevant when sampling
                # new experience based on existing policy
                epsilon = 0.1) # typical default value

# We sampled experience from an agent
# navigating from a random starting
# to a goal position in 2 x 2 Grid World.

# Create the 2 x 2 Grid World environment
env <- gridworldEnvironment
print(env)

# Define state and action sets
states <- c("s1", "s2", "s3", "s4")
actions <- c("up", "down", "left", "right")

# Set seed so get same original data
# each time you run sampleExperience
set.seed(1234)

# Original data set (recreated)
data <- sampleExperience(N = 1000, 
                         env = env, 
                         states = states, 
                         actions = actions)

head(data)

# Perform reinforcement learning
model <- ReinforcementLearning(data, 
                               s = "State", 
                               a = "Action", 
                               r = "Reward", 
                               s_new = "NextState", 
                               control = control)

# Print result
print(model)

# Now we update the existing policy
# with a new data set and we deliberately
# choose "epsilon-greedy" action selection

# Sample N = 1000 sequences from the environment 
# using epsilon-greedy action selection
data_new <- sampleExperience(N = 1000, 
                             env = env, 
                             states = states, 
                             actions = actions, 
                             # note we are using the
                             # existing model from before
                             model = model, 
                             actionSelection = "epsilon-greedy", 
                             control = control)

# What are the model and actionSelection
# arguments doing?

head(data_new)
##   State Action Reward NextState
## 1    s2  right     -1        s3
## 2    s4  right     -1        s4
## 3    s4  right     -1        s4
## 4    s4  right     -1        s4
## 5    s2  right     -1        s3
## 6    s1   down     -1        s2

data_new

# Update the existing policy using new training data
model_new <- ReinforcementLearning(data_new, 
                                   s = "State", 
                                   a = "Action", 
                                   r = "Reward", 
                                   s_new = "NextState", 
                                   control = control,
                                   model = model)

# Print result
print(model_new)
## State-Action function Q
##        right         up       down       left
## s1 -0.643587 -0.6320560  0.7657318 -0.6314927
## s2  3.530829 -0.6407675  0.7714129  0.7427914
## s3  3.548196  9.0608344  3.5521760  0.7382102
## s4 -1.939574 -1.8922783 -1.8835278 -1.8856132
## 
## Policy
##      s1      s2      s3      s4 
##  "down" "right"    "up"  "down" 
## 
## Reward (last iteration)
## [1] 1211

summary(model_new)
## 
## Model details
## Learning rule:           experienceReplay
## Learning iterations:     2
## Number of states:        4
## Number of actions:       4
## Total Reward:            1211
## 
## Reward details (per iteration)
## Min:                     -263
## Max:                     1211
## Average:                 474
## Median:                  474
## Standard deviation:      1042.275
# Plot reinforcement learning curve

plot(model_new)
